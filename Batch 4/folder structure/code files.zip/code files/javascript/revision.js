// const apple = "wine";

// if (apple === "wine") {
//   console.log("Wine is a cool color");
// } else {
//   console.log("Red is the cool color hesre");
// }

// const age = 12;

// if (age > 18) {
//   console.log("Go on to cast your vote");
// } else {
//   console.log("So sorry you can't vote now");
// }

// if (age > 18 && age < 70) {
//   console.log("You are of the right age and you can vote");
// } else if (age > 70) {
//   console.log("So sorry you are above voting age");
// } else {
//   console.log("You are under age");
// }

for (let i = 1; i <= 100; i++) {
  console.log(i);
}

String;
Number;
Boolean;
null;
undefined;

Object;
Array;

const myArray = [22, 63, 45, 13, 37, 27, 69];

console.log(
  myArray.map((myNum, index) => {
    return myNum * 100;
  })
);
