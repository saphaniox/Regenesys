import './Company.css'
const Company = () => {
  return (
    <div className="companyContainer">
        <h1>This is the company Page</h1>
    </div>
  )
}

export default Company