const a = 34;
const b = 87;

export { a, b };

export const c = 67;

// const testName = "Sammy Best";

// export default testName;
