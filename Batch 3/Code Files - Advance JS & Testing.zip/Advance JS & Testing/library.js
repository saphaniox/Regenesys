// function Greet (name){
//     return `This is from the Library Script, My Name is ${name}`
// }

// export default Greet


export function Greet (name){
    return `This is from the Library Script, My Name is ${name}`
}

export function SayHello (name){
    return ` My Name is ${name} and i am saying hello from The Libuary Script`
}
