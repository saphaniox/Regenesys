import Home from "./pages/Home/Home";
import Header from "./components/header/Header";

const App = () => {
  return (
    <div>
      <Header />
      <Home />
    </div>
  );
};

export default App;
