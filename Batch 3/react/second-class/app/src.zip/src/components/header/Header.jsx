import Button from "../reuseable/Button";
import "./Header.css";

const Header = () => {
  return (
    <div className="headerContaine">
      <section className="logoNav">
        <img src="./logo.svg" alt="" />
        <main className="navs">
          <nav>Features</nav>
          <nav>Company</nav>
          <nav>Career</nav>
          <nav>About</nav>
        </main>
      </section>
      <section className="btns">
        <nav>Login</nav>
        <Button title="Register" />
      </section>
    </div>
  );
};

export default Header;
