const Hero = () => {
  return (
    <div>
      <h1>This is the Hero Page</h1>
    </div>
  );
};

export default Hero;
