import Hero from "../../components/home/Hero";

const Home = () => {
  return (
    <div>
      <Hero />
    </div>
  );
};

export default Home;
